const express = require('express');
const router = express.Router();
const generateInvoicePDF = require("../utils/generateInvoicePDF");
const path = require('path');
const fs = require('fs');

// Ensure temp directory exists
const tempDir = path.join(__dirname, "../temp");
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

router.post('/generate-pdf', async (req, res) => {
  try {
    const { html } = req.body;

    if (!html) {
      return res.status(400).json({ error: "HTML content is required" });
    }

    const outputPath = path.join(tempDir, `invoice-${Date.now()}.pdf`);

    await generateInvoicePDF(html, outputPath);

    res.download(outputPath, "invoice.pdf", (err) => {
      if (err) {
        console.error("Download error:", err);
      }
      setTimeout(() => {
        if (fs.existsSync(outputPath)) {
          fs.unlinkSync(outputPath);
        }
      }, 5000);
    });
  } catch (err) {
    console.error("PDF generation error:", err);
    res.status(500).json({
      error: "PDF generation failed",
      details: err.message,
    });
  }
});

module.exports = router;