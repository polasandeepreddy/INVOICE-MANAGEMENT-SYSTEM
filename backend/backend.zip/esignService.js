const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
const puppeteer = require('puppeteer');
const router = express.Router();



// eMudhra Configuration - Replace with your actual credentials
const EMUDHRA_CONFIG = {
    baseURL: process.env.EMUDHRA_API_URL || 'https://api.hub.emsign.com/v1',
    accountNo: process.env.EMUDHRA_ACCOUNT_NO || 'YOUR_ACCOUNT_NO',
    accessKey: process.env.EMUDHRA_ACCESS_KEY || 'YOUR_ACCESS_KEY',
    clientId: process.env.EMUDHRA_CLIENT_ID || 'YOUR_CLIENT_ID',
    clientSecret: process.env.EMUDHRA_CLIENT_SECRET || 'YOUR_CLIENT_SECRET',
    webhookSecret: process.env.EMUDHRA_WEBHOOK_SECRET || 'YOUR_WEBHOOK_SECRET'
};

// Store signature requests (Use Redis or Database in production)
const signatureRequests = new Map();

// Helper: Generate authentication headers for eMudhra API
function getAuthHeaders() {
    const timestamp = Date.now();
    const nonce = crypto.randomBytes(16).toString('hex');
    const signature = crypto
        .createHmac('sha256', EMUDHRA_CONFIG.clientSecret)
        .update(`${EMUDHRA_CONFIG.clientId}${timestamp}${nonce}`)
        .digest('hex');

    return {
        'X-Account-No': EMUDHRA_CONFIG.accountNo,
        'X-Access-Key': EMUDHRA_CONFIG.accessKey,
        'X-Client-Id': EMUDHRA_CONFIG.clientId,
        'X-Timestamp': timestamp.toString(),
        'X-Nonce': nonce,
        'X-Signature': signature,
        'Content-Type': 'application/json'
    };
}

async function generatePDFBufferFromBase64(base64Image) {
    const browser = await puppeteer.launch({
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu'
        ]
    });

    try {
        const page = await browser.newPage();
        const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { margin: 0; padding: 0; background: white; }
    .page { width: 210mm; min-height: 297mm; display: flex; align-items: center; justify-content: center; }
    img { width: 100%; height: auto; display: block; }
  </style>
</head>
<body>
  <div class="page">
    <img src="${base64Image}" alt="Invoice" />
  </div>
</body>
</html>`;

        await page.setContent(html, {
            waitUntil: 'networkidle0',
            timeout: 30000
        });

        const pdfBuffer = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: {
                top: '10mm',
                right: '10mm',
                bottom: '10mm',
                left: '10mm'
            }
        });

        return pdfBuffer;
    } finally {
        await browser.close();
    }
}

// Endpoint 1: Initiate eSign process
router.post('/api/esign/initiate', async (req, res) => {
    try {
        const { invoiceData, invoiceImage } = req.body;
        
        if (!invoiceData || !invoiceImage) {
            return res.status(400).json({
                success: false,
                error: 'Missing required data'
            });
        }

        // ✅ STEP 1: Convert Image → PDF (IMPORTANT FIX)
        const pdfBuffer = await generatePDFBufferFromBase64(invoiceImage);
        const pdfBase64 = pdfBuffer.toString('base64');

        // ✅ STEP 2: Generate request ID
        const requestId = crypto.randomBytes(16).toString('hex');
        
        // ✅ STEP 3: Prepare document
        const documentData = {
            requestId: requestId,
            document: {
                name: `Invoice_${invoiceData.invoice_number || 'JA'}_${Date.now()}.pdf`,
                content: pdfBase64,   // ✅ now correct
                format: 'base64'
            },
            signers: [{
                name: invoiceData.business_name || 'JAYARAMA ASSOCIATES',
                email: invoiceData.business_email || 'accounts@jayarama.com',
                mobile: invoiceData.business_phone || '9866669777',
                signerOrder: 1,
                signaturePosition: {
                    page: 1,
                    x: 400,
                    y: 750,
                    width: 150,
                    height: 50
                }
            }],
            callbackUrl: `${process.env.BACKEND_URL || 'http://localhost:5000'}/api/esign/webhook`,
            redirectUrl: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/signature-complete`,
            expiryDays: 7
        };
        
        // Store request
        signatureRequests.set(requestId, {
            status: 'pending',
            invoiceData: invoiceData,
            createdAt: new Date(),
            imageData: invoiceImage
        });
        
        // Demo mode
        const demoMode = true;
        
        let response;
        if (demoMode) {
            response = {
                data: {
                    success: true,
                    signingUrl: `https://demo.emsign.com/sign/${requestId}`,
                    message: 'Signing initiated successfully'
                }
            };
        } else {
            response = await axios.post(
                `${EMUDHRA_CONFIG.baseURL}/signature/initiate`,
                documentData,
                { headers: getAuthHeaders() }
            );
        }
        
        if (response.data.success) {
            res.json({
                success: true,
                requestId: requestId,
                signingUrl: response.data.signingUrl,
                status: 'initiated'
            });
        } else {
            throw new Error(response.data.message || 'Failed to initiate signing');
        }
        
    } catch (error) {
        console.error('eSign initiation error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to initiate eSign process'
        });
    }
});

// Endpoint 2: Webhook for signature completion
router.post('/api/esign/webhook', async (req, res) => {
    try {
        // Verify webhook signature (for security)
        const signature = req.headers['x-webhook-signature'];
        const payload = JSON.stringify(req.body);
        const expectedSignature = crypto
            .createHmac('sha256', EMUDHRA_CONFIG.webhookSecret)
            .update(payload)
            .digest('hex');
        
        // Skip verification in demo mode
        const demoMode = true;
        if (!demoMode && signature !== expectedSignature) {
            return res.status(401).json({ error: 'Invalid signature' });
        }
        
        const { requestId, status, signedDocumentUrl, signatureDetails } = req.body;
        
        // Update request status
        if (signatureRequests.has(requestId)) {
            const requestData = signatureRequests.get(requestId);
            requestData.status = status || 'completed';
            requestData.signedDocumentUrl = signedDocumentUrl || `https://demo.emsign.com/signed/${requestId}`;
            requestData.signatureDetails = signatureDetails || {
                signedBy: 'Authorized Signatory',
                timestamp: new Date().toISOString(),
                digitalId: 'DEMO-SIG-001'
            };
            requestData.completedAt = new Date();
            signatureRequests.set(requestId, requestData);
        }
        
        res.json({ success: true });
        
    } catch (error) {
        console.error('Webhook error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Endpoint 3: Check signature status
router.get('/api/esign/status/:requestId', async (req, res) => {
    try {
        const { requestId } = req.params;
        const requestData = signatureRequests.get(requestId);
        
        if (!requestData) {
            return res.status(404).json({ 
                success: false, 
                error: 'Request not found' 
            });
        }
        
        // In demo mode, simulate completion after 10 seconds
        if (requestData.status === 'pending' && 
            (Date.now() - requestData.createdAt.getTime()) > 10000) {
            requestData.status = 'completed';
            requestData.signedDocumentUrl = `https://demo.emsign.com/signed/${requestId}`;
            requestData.signatureDetails = {
                signedBy: 'Authorized Signatory',
                timestamp: new Date().toISOString(),
                digitalId: 'DEMO-SIG-001'
            };
            signatureRequests.set(requestId, requestData);
        }
        
        res.json({
            success: true,
            status: requestData.status,
            signedDocumentUrl: requestData.signedDocumentUrl,
            signatureDetails: requestData.signatureDetails
        });
        
    } catch (error) {
        console.error('Status check error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Endpoint 4: Get signed document
router.get('/api/esign/document/:requestId', async (req, res) => {
    try {
        const { requestId } = req.params;
        const requestData = signatureRequests.get(requestId);
        
        if (!requestData || !requestData.signedDocumentUrl) {
            return res.status(404).json({ error: 'Signed document not found' });
        }
        
        // For demo, return the original image with signature overlay
        if (requestData.imageData) {
            const imageBuffer = Buffer.from(requestData.imageData.split(',')[1], 'base64');
            res.setHeader('Content-Type', 'image/jpeg');
            res.setHeader('Content-Disposition', `attachment; filename=signed_invoice_${requestId}.jpg`);
            res.send(imageBuffer);
        } else {
            res.json({ error: 'Document not available' });
        }
        
    } catch (error) {
        console.error('Document fetch error:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;