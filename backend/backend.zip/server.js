const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const dotenv = require('dotenv');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const invoiceRoutes = require("./routes/invoiceRoutes");
const generateInvoicePDF = require('./utils/generateInvoicePDF');

const tempDir = path.join(__dirname, 'temp');
if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
}

dotenv.config();

const app = express();

// ========== CORS CONFIGURATION ==========
const corsOptions = {
    origin: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Authorization'],
    optionsSuccessStatus: 200
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/api/invoice", invoiceRoutes);

// ========== DEFAULT BUSINESS CONSTANTS ==========
const DEFAULT_BUSINESS_NAME = 'JAYARAMA ASSOCIATES';
const DEFAULT_BUSINESS_ADDRESS = `Plot No: 12, Road No: 1A, CZECH COLONY,
SANATH NAGAR, HYDERABAD - 500018
Phone no. : 9866669777
Email : jayaramassociates@yahoo.com
PAN : AMIPM2958D
GSTIN : 36AMIPM2958D1ZY
State: 36-Telangana`;
const DEFAULT_PLACE_OF_SUPPLY = '36-Telangana';
const DEFAULT_TAX_RATE = 18;

// MySQL Database Connection
const db = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'invoice_manager',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    timezone: '+05:30',
    namedPlaceholders: true
});

const promiseDb = db.promise();

// CloudSigner Configuration
const CLOUDSIGNER_URL = process.env.CLOUDSIGNER_URL || 'http://localhost:1621';
const CLOUDSIGNER_API_KEY = process.env.CLOUDSIGNER_API_KEY || 'Sample';
const CLOUDSIGNER_CERTIFICATE_ID = process.env.CLOUDSIGNER_CERTIFICATE_ID || '';

// OTP Store
const otpStore = new Map();

// Configure email transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// Helper Functions
function getFinancialYear() {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    
    if (month >= 4) {
        return `${year.toString().slice(-2)}-${(year + 1).toString().slice(-2)}`;
    } else {
        return `${(year - 1).toString().slice(-2)}-${year.toString().slice(-2)}`;
    }
}

function validateUsername(username) {
    const usernameRegex = /^[A-Z][A-Za-z0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]*$/;
    return usernameRegex.test(username) && username.length >= 2;
}

function calculateTaxAmounts(baseAmount, placeOfSupply, taxRate = DEFAULT_TAX_RATE) {
    const isIntraState = placeOfSupply && (
        placeOfSupply.includes('36') || 
        placeOfSupply.includes('Telangana') ||
        placeOfSupply.includes('36-Telangana')
    );
    
    const taxAmount = (baseAmount * taxRate) / 100;
    
    let result;
    if (isIntraState) {
        result = {
            baseAmount: baseAmount,
            sgst: parseFloat((taxAmount / 2).toFixed(2)),
            cgst: parseFloat((taxAmount / 2).toFixed(2)),
            igst: 0,
            totalAmount: parseFloat((baseAmount + taxAmount).toFixed(2)),
            taxRate: taxRate
        };
    } else {
        result = {
            baseAmount: baseAmount,
            sgst: 0,
            cgst: 0,
            igst: parseFloat(taxAmount.toFixed(2)),
            totalAmount: parseFloat((baseAmount + taxAmount).toFixed(2)),
            taxRate: taxRate
        };
    }
    
    return result;
}

function convertToWords(amount) {
    if (amount === 0) return 'Zero Rupees only';
    
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
                  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
                  'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    
    function convert(n) {
        if (n < 20) return ones[n];
        if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
        if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + convert(n % 100) : '');
        if (n < 100000) return convert(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + convert(n % 1000) : '');
        if (n < 10000000) return convert(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 ? ' ' + convert(n % 100000) : '');
        return convert(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 ? ' ' + convert(n % 10000000) : '');
    }
    
    const rupees = Math.floor(amount);
    const paise = Math.round((amount - rupees) * 100);
    
    let words = convert(rupees) + ' Rupees';
    if (paise > 0) {
        words += ' and ' + convert(paise) + ' Paise';
    }
    return words + ' only';
}

// PDF Helper Functions
const formatRupeesForPDF = (amount) => {
    if (amount === undefined || amount === null) return '₹0.00';
    const num = typeof amount === 'number' ? amount : parseFloat(amount);
    if (isNaN(num)) return '₹0.00';
    return `₹${num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const formatIndianNumber = (amount) => {
    if (amount === undefined || amount === null) return '0';
    const num = typeof amount === 'number' ? amount : parseFloat(amount);
    if (isNaN(num)) return '0';
    return num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};


const buildInvoiceHTML = (invoice) => {
    // Helper function to escape HTML and prevent XSS
    const escapeHtml = (str) => {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    };

    // Sanitize URLs to prevent XSS
    const sanitizeUrl = (url) => {
        if (!url) return '';
        const urlStr = String(url).toLowerCase().trim();
        const dangerous = ['javascript:', 'data:text/html', 'vbscript:', 'file:'];
        if (dangerous.some(protocol => urlStr.startsWith(protocol))) {
            return '';
        }
        return url;
    };

    // Format date consistently
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr;
        return date.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    };

    // Function to merge items with same HSN
    const mergeItemsByHSN = (items) => {
        if (!items || items.length === 0) return [];
        
        const grouped = new Map();
        
        items.forEach(item => {
            const hsn = item.hsn || '998399';
            const quantity = Number(item.quantity) || 1;
            const price = Number(item.price) || 0;
            const amount = quantity * price;
            
            if (grouped.has(hsn)) {
                const existing = grouped.get(hsn);
                if (item.description && item.description !== existing.description) {
                    existing.description = existing.description + ' + ' + item.description;
                }
                existing.quantity += quantity;
                const totalValue = (existing.price * (existing.quantity - quantity)) + amount;
                existing.price = totalValue / existing.quantity;
            } else {
                grouped.set(hsn, { 
                    ...item, 
                    description: item.description || 'PROFESSIONAL FEE',
                    quantity: quantity,
                    price: price
                });
            }
        });
        
        return Array.from(grouped.values());
    };

    // IMPROVED: Function to determine if same state (intra-state vs inter-state)
    const isSameState = (invoice) => {
        // Check explicit flag first
        if (invoice.same_state === true) return true;
        if (invoice.same_state === false) return false;
        
        // Get the place of supply (most important for tax calculation)
        let placeOfSupply = invoice.place_of_supply || '';
        
        // If place_of_supply is empty, try to get from client_state or default
        if (!placeOfSupply) {
            placeOfSupply = invoice.client_state || DEFAULT_PLACE_OF_SUPPLY || '36-Telangana';
        }
        
        // Convert to string and trim
        placeOfSupply = String(placeOfSupply).trim().toLowerCase();
        
        // Check if place of supply is Telangana (state code 36)
        const isTelangana = placeOfSupply.includes('36') || 
                           placeOfSupply.includes('telangana') ||
                           placeOfSupply === '36-telangana';
        
        // For this business (JAYARAMA ASSOCIATES), the business state is Telangana (36)
        // So same state = true only if place of supply is Telangana
        return isTelangana;
    };

    // Safely get and merge items
    let items = Array.isArray(invoice.items) && invoice.items.length > 0 
        ? invoice.items 
        : (invoice.amount ? [{ 
            description: 'PROFESSIONAL FEE', 
            hsn: '998399', 
            quantity: 1, 
            price: Number(invoice.amount) || 0 
        }] : []);
    
    // Only merge if there are multiple items with same HSN
    const hasDuplicateHSN = items.length > 1 && 
        new Set(items.map(i => i.hsn || '998399')).size < items.length;
    
    if (hasDuplicateHSN) {
        items = mergeItemsByHSN(items);
    }

    // Calculate subtotal from items
    const subtotal = items.reduce(
        (sum, item) => sum + ((Number(item.quantity) || 0) * (Number(item.price) || 0)),
        0
    );

    // Determine if same state for tax calculation
    const sameState = isSameState(invoice);
    
    // Auto-calculate taxes based on state (9% + 9% = 18% total for same state, 18% IGST for different state)
    let sgst = 0;
    let cgst = 0;
    let igst = 0;
    
    if (sameState) {
        // Same state (Intra-state): SGST @ 9% and CGST @ 9%
        sgst = parseFloat((subtotal * 0.09).toFixed(2));
        cgst = parseFloat((subtotal * 0.09).toFixed(2));
    } else {
        // Different state (Inter-state): IGST @ 18%
        igst = parseFloat((subtotal * 0.18).toFixed(2));
    }
    
    const total = parseFloat((subtotal + sgst + cgst + igst).toFixed(2));
    
    const received = Number(invoice.received) || 0;
    const balance = parseFloat((total - received).toFixed(2));

    const formatCurrency = (value) => {
        const num = Number(value);
        if (isNaN(num)) return '₹ 0.00';
        return `₹ ${num.toLocaleString("en-IN", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        })}`;
    };

    // Convert number to words
    const convertToWords = (amount) => {
        const num = Number(amount);
        if (isNaN(num)) return 'Rupees Zero Only';
        
        const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
                      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
                      'Seventeen', 'Eighteen', 'Nineteen'];
        const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
        
        const numToWords = (n) => {
            if (n < 20) return ones[n];
            if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
            if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + numToWords(n % 100) : '');
            if (n < 100000) return numToWords(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + numToWords(n % 1000) : '');
            if (n < 10000000) return numToWords(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 ? ' ' + numToWords(n % 100000) : '');
            return numToWords(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 ? ' ' + numToWords(n % 10000000) : '');
        };
        
        const rupees = Math.floor(num);
        const paise = Math.round((num - rupees) * 100);
        
        let words = 'Rupees ' + numToWords(rupees);
        if (paise > 0) {
            words += ' and ' + numToWords(paise) + ' Paise';
        }
        return words + ' Only';
    };

    // Generate table rows
    const rows = items.map((item, index) => {
        const quantity = Number(item.quantity) || 1;
        const price = Number(item.price) || 0;
        const amount = quantity * price;
        
        return `
            <tr>
                <td style="text-align: center; padding: 8px; font-family: 'Times New Roman', Times, serif; font-size: 12px; border: none; color: #000000;">${index + 1}.</td>
                <td style="padding: 8px; font-family: 'Times New Roman', Times, serif; font-size: 12px; text-align: left; border: none; color: #000000;">${escapeHtml(item.description || 'PROFESSIONAL FEE')}</td>
                <td style="text-align: center; padding: 8px; font-family: 'Times New Roman', Times, serif; font-size: 12px; border: none; color: #000000;">${escapeHtml(item.hsn || '998399')}</td>
                <td style="text-align: center; padding: 8px; font-family: 'Times New Roman', Times, serif; font-size: 12px; border: none; color: #000000;">${quantity}</td>
                <td style="text-align: center; padding: 8px; font-family: 'Times New Roman', Times, serif; font-size: 12px; border: none; color: #000000;">${formatCurrency(price)}</td>
                <td style="text-align: left; padding: 8px; font-family: 'Times New Roman', Times, serif; font-size: 12px; border: none; color: #000000;">${formatCurrency(amount)}</td>
            </tr>
        `;
    }).join("");
    
    const COMPLETE_BUSINESS_ADDRESS = `Plot No: 12, Road No: 1A, Czech Colony,</br>
    Sanath Nagar, Hyderabad - 500018<br/>
    Phone No. : 9866669777<br/>
    Email : jayaramassociates@yahoo.com<br/>
    PAN : AMIPM2958D<br/>
    GSTIN : 36AMIPM2958D1ZY<br/>
    State: 36-Telangana`;

    const getBusinessAddress = () => {
        if (invoice.business_address && invoice.business_address.includes('PAN')) {
            return escapeHtml(invoice.business_address);
        }
        return COMPLETE_BUSINESS_ADDRESS;
    };

    // Safely handle logo URLs
    const companyLogoUrl = sanitizeUrl(invoice.company_logo) || "JAYARAMA LOGO1.png";
    const fallbackLogo = "https://placehold.co/140x120?text=JAYARAMA+LOGO";
    
    const hasSignature = (invoice.signature_data && invoice.signature_data !== 'CloudSigner_Digital_Signature') || 
                        (invoice.cloud_signer_signature_url && invoice.cloud_signer_signature_url !== 'null' && invoice.cloud_signer_signature_url !== '');    
    
    const signatureSrc = sanitizeUrl(invoice.cloud_signer_signature_url || invoice.signature_data);
    const signatoryMarginTop = hasSignature ? '-5px' : '70px';

    const descriptionText = (invoice.description && 
        invoice.description.length > 1 && 
        invoice.description !== 'd' && 
        invoice.description !== 'D' && 
        invoice.description !== 'G')
        ? escapeHtml(invoice.description) 
        : 'Professional Fee for Services Rendered';

    // Format client address properly
    const formatAddress = (address) => {
        if (!address) return '';
        return escapeHtml(address).toLowerCase().replace(/\b\w/g, char => char.toUpperCase());
    };

    // Return the HTML template
    return `<!DOCTYPE html>
    <html>
    <head>
    <meta charset="UTF-8">
    <title>Tax Invoice</title>
    <style>
        @page { 
            size: A4;
            margin: 1.5cm !important;
        }
        @media print {
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .no-print {
                display: none;
            }
        }
        body {
            margin: 0;
            padding: 0;
            background: #fff;
            font-family: 'Times New Roman', Times, serif;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border: none;
        }
        th, td {
            border: none;
        }
    </style>
    </head>
    <body style="font-family: 'Times New Roman', Times, serif; margin: 0; padding: 0; color: #000; background: #fff;">
    
    <div style="width: 100%; margin: 0; padding: 0;">
    
        <!-- Top Section: Company Details + Logo -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 18px; color: #000000; font-weight: bold;">
                    ${escapeHtml(invoice.business_name || 'JAYARAMA ASSOCIATES')}
                </div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 11px; font-weight: normal; color: #000000; margin-top: 5px; line-height: 1.5;">
                    ${getBusinessAddress()}
                </div>
            </div>
            <div style="text-align: center;">
                <img 
                    src="${companyLogoUrl}"
                    alt="Company Logo" 
                    style="max-width: 140px; max-height: 120px; object-fit: contain; margin-bottom: 5px; transform: translate(-40px, 10px);"
                    onerror="this.onerror=null; this.src='${fallbackLogo}';"
                />
            </div>
        </div>
    
        <!-- Invoice Title -->
        <div style="margin-bottom: 5px;">
            <div style="
                font-family: 'Times New Roman', Times, serif;
                font-size: 20px;
                font-weight: bold;
                text-align: center;
                display: block;
                margin-top: 10px;
                color: #00AEEF;
                border-bottom: none;
                letter-spacing: 0px;
                text-transform: capitalize;
            ">
                Tax Invoice
            </div>
        </div>
    
        <!-- Bill To & Invoice Details -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 20px;">
            <div style="flex: 1;">
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; border-bottom: 1px solid #f1f5f9; display: inline-block; font-weight: bold;">
                    Bill To
                </div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 14px; margin-top: 5px; color: #000000; font-weight: bold;">
                    ${escapeHtml(invoice.client_name || '')}
                </div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; white-space: pre-line; margin-top: -8px; line-height: 1.4; font-weight: normal;">
                    ${formatAddress(invoice.client_address || '')}
                </div>
                ${invoice.client_phone ? `
                    <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; margin-top: 3px;">
                        Phone: ${escapeHtml(invoice.client_phone)}
                    </div>
                ` : ''}
                ${invoice.client_gst ? `
                    <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; margin-top: 3px;">
                        GSTIN: ${escapeHtml(invoice.client_gst)}
                    </div>
                ` : ''}
                ${invoice.client_email ? `
                    <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; margin-top: 3px;">
                        Email: ${escapeHtml(invoice.client_email)}
                    </div>
                ` : ''}
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; margin-top: 3px;">
                    State: ${escapeHtml(invoice.client_state || '36-Telangana')}
                </div>
            </div>
            <div style="text-align: right; margin-top: 30px; color: #000000;">
                <p style="font-family: 'Times New Roman', Times, serif; font-size: 13px; color: #000000; margin: 2px 0; font-weight: normal;">
                    <span style="font-weight: normal;">Place of supply:</span>
                    <span style="font-weight: normal;">${escapeHtml(invoice.place_of_supply || '36-Telangana')}</span>
                </p>
                <p style="font-family: 'Times New Roman', Times, serif; font-size: 13px; margin-top: 10px; margin-bottom: 10px; color: #000000; font-weight: bold;">
                    Invoice No: ${escapeHtml(invoice.invoice_number || '')}
                </p>
                <p style="font-family: 'Times New Roman', Times, serif; font-size: 12px; margin-top: 5px; color: #000000; font-weight: bold;">
                    Date: ${formatDate(invoice.date || '')}
                </p>
            </div>
        </div>
    
        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px; font-family: 'Times New Roman', Times, serif; border: none;">
            <thead>
                <tr style="background: #00AEEF;">
                    <th style="width: 42px; padding: 10px; color: white; text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 11px; background: #00AEEF; border: none; font-weight: bold;">S.No.</th>
                    <th style="padding: 10px; color: white; text-align: left; font-family: 'Times New Roman', Times, serif; font-size: 11px; background: #00AEEF; border: none; font-weight: bold;">Item Name</th>
                    <th style="width: 80px; padding: 10px; color: white; text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 11px; background: #00AEEF; border: none; font-weight: bold;">HSN/SAC</th>
                    <th style="width: 60px; padding: 10px; color: white; text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 11px; background: #00AEEF; border: none; font-weight: bold;">Qty</th>
                    <th style="width: 110px; padding: 10px; color: white; text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 11px; background: #00AEEF; border: none; font-weight: bold;">Price/Unit</th>
                    <th style="width: 110px; padding: 10px; color: white; text-align: left; font-family: 'Times New Roman', Times, serif; font-size: 11px; background: #00AEEF; border: none; font-weight: bold;">Amount</th>
                </tr>
            </thead>
            <tbody>
                ${rows || '<tr><td colspan="6" style="text-align: center; padding: 40px; border: none;">No items added</td>'}
            </tbody>
        </table>
    
        <!-- Bottom Section: Description + Summary -->
        <div style="display: flex; justify-content: space-between; margin-top: 20px;">
            <div style="flex: 1; margin-right: 20px;">
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; margin-bottom: 5px; color: #000000; font-weight: bold; line-height: 1.4">
                    Description
                </div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 11px; color: #000000; width: 100%; text-transform: uppercase; margin: 0;">
                    ${descriptionText}
                </div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; margin-top: 20px; margin-bottom: 5px; color: #000000; font-weight: bold;">
                    Invoice Amount In Word
                </div>
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; color: #000000; text-transform: capitalize; margin: 0;">
                    ${invoice.amount_in_words ? escapeHtml(invoice.amount_in_words) : convertToWords(total)}
                </div>
            </div>
            <div class="p-tots" style="width: 250px;">
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0; font-family: 'Times New Roman', Times, serif; font-size: 12px; font-weight: bold;">
                    <span>Sub Total</span>
                    <span style="text-align: left; min-width: 100px;">${formatCurrency(subtotal)}</span>
                </div>
                
                ${sameState ? `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0; font-family: 'Times New Roman', Times, serif; font-size: 12px;">
                        <span>SGST @ 9%</span>
                        <span style="text-align: left; min-width: 100px;">${formatCurrency(sgst)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0; font-family: 'Times New Roman', Times, serif; font-size: 12px;">
                        <span>CGST @ 9%</span>
                        <span style="text-align: left; min-width: 100px;">${formatCurrency(cgst)}</span>
                    </div>
                ` : `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0; font-family: 'Times New Roman', Times, serif; font-size: 12px;">
                        <span>IGST @ 18%</span>
                        <span style="text-align: left; min-width: 100px;">${formatCurrency(igst)}</span>
                    </div>
                `}
                
                <div style="background: #00AEEF; color: black; display: flex; justify-content: space-between; padding: 10px; border-radius: 5px; margin: 10px 0; font-family: 'Times New Roman', Times, serif; font-size: 13px;">
                    <span style="font-weight: bold;">TOTAL</span>
                    <span style="font-weight: bold; text-align: left; min-width: 100px;">${formatCurrency(total)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0; font-family: 'Times New Roman', Times, serif; font-size: 12px;">
                    <span>Received</span>
                    <span style="text-align: left; min-width: 100px;">${formatCurrency(received)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0; font-family: 'Times New Roman', Times, serif; font-size: 12px;">
                    <span style="font-weight: bold;">Balance Due</span>
                    <span style="font-weight: bold; text-align: left; min-width: 100px;">${formatCurrency(balance)}</span>
                </div>
            </div>
        </div>
    
        <!-- Terms and Conditions -->
        <div style="margin-top: 20px;">
            <div style="font-family: 'Times New Roman', Times, serif; letter-spacing: 0px; font-size: 12px; color: #000000; text-transform: capitalize; font-weight: bold;">
                Terms and Conditions
            </div>
            <div style="font-family: 'Times New Roman', Times, serif; font-size: 11px; color: #000000; line-height: 1.3; font-weight: normal;">
                ${escapeHtml(invoice.terms_conditions || 'Thanks for doing business with us!')}
            </div>
        </div>
    
        <!-- Bank Details & Signature Section -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-top: 10px; border-top: none; padding-top: 5px;">
            <div style="flex: 1;">
                <div style="font-family: 'Times New Roman', Times, serif; margin-bottom: 10px; text-decoration: underline; font-size: 11px; color: #000000;">
                    Pay To-
                </div>
                <div style="margin-bottom: 5px; font-size: 11px; font-family: 'Times New Roman', Times, serif; color: #000000;">
                    Bank Name : <b>${escapeHtml(invoice.bank_name || 'HDFC BANK')}</b>
                </div>
                <div style="margin-bottom: 5px; font-size: 11px; font-family: 'Times New Roman', Times, serif; color: #000000;">
                    Bank Account No : <b>${escapeHtml(invoice.bank_account_no || '50100123456789')}</b>
                </div>
                <div style="margin-bottom: 5px; font-size: 11px; font-family: 'Times New Roman', Times, serif; color: #000000;">
                    Bank IFSC code : <b>${escapeHtml(invoice.bank_ifsc || 'HDFC0001234')}</b>
                </div>
                <div style="margin-bottom: 5px; font-size: 11px; font-family: 'Times New Roman', Times, serif; color: #000000;">
                    Account holder's name : <b>${escapeHtml(invoice.account_holder || 'JAYARAMA ASSOCIATES')}</b>
                </div>
            </div>
            
            <!-- Signature Area -->
            <div style="text-align: right; min-width: 180px; padding-right: 4px;">
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; margin-bottom: 2px; margin-top: 0px; color: #000000; font-weight: normal;">
                    For : JAYARAMA ASSOCIATES
                </div>
                
                ${hasSignature && signatureSrc ? `
                <div style="text-align: right; margin-bottom: 0px; position: relative; left: 10px; top: 0px;">
                    <img 
                        src="${signatureSrc}" 
                        alt="Digital Signature" 
                        style="width: 180px; height: 80px; object-fit: contain; background: transparent; border: none; border-radius: 0;" 
                        onerror="this.style.display='none';"
                    />
                </div>
                ` : ''}
                
                <div style="font-family: 'Times New Roman', Times, serif; font-size: 12px; margin-top: ${signatoryMarginTop}; margin-bottom: 0px; letter-spacing: 1px; color: #000000; font-weight: normal; text-transform: capitalize; padding-right: 35px; line-height: 1.2;">
                    Authorized Signatory
                    ${invoice.signature_data === 'CloudSigner_Digital_Signature' ? `
                    <span style="display: inline-block; background: #4c9aff; color: white; font-size: 8px; padding: 2px 6px; border-radius: 10px; margin-left: 8px; vertical-align: middle;">
                        ✓ Digitally Signed
                    </span>
                    ` : ''}
                </div>
                
                ${invoice.signed_at ? `
                <div style="font-size: 8px; color: #666; margin-top: 0px; text-align: right; line-height: 1.2;">
                    Signed: ${formatDate(invoice.signed_at)}
                </div>
                ` : ''}
            </div>
        </div>
    </div>
    </body>
    </html>
    `;
};

// Legacy PDFKit manual generation removed. Use HTML / Puppeteer for PDF output.


// Initialize Database Tables
async function initializeDatabase() {
    try {
        // Create users table
        await promiseDb.execute(`
            CREATE TABLE IF NOT EXISTS users (
                id VARCHAR(50) PRIMARY KEY,
                full_name VARCHAR(255),
                username VARCHAR(100),
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'super_admin', 'user') DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_username (username),
                INDEX idx_email (email)
            )
        `);

        // Create Clients Table
        await promiseDb.execute(`
            CREATE TABLE IF NOT EXISTS clients (
                id VARCHAR(50) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                address TEXT,
                branch VARCHAR(255),
                gst_number VARCHAR(50),
                phone VARCHAR(20),
                email VARCHAR(255),
                created_by VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
                INDEX idx_client_name (name),
                INDEX idx_branch (branch),
                INDEX idx_gst_number (gst_number),
                INDEX idx_created_by (created_by)
            )
        `);

        // Create Invoices Table with all eSign columns
        await promiseDb.execute(`
            CREATE TABLE IF NOT EXISTS invoices (
                id VARCHAR(50) PRIMARY KEY,
                user_id VARCHAR(50) NOT NULL,
                created_by_name VARCHAR(255),
                invoice_number VARCHAR(100) NOT NULL,
                date DATE NOT NULL,
                business_name TEXT,
                business_address TEXT,
                client_id VARCHAR(50),
                client_name TEXT,
                client_address TEXT,
                client_branch VARCHAR(255),
                client_gst VARCHAR(50),
                client_phone VARCHAR(20),
                client_email VARCHAR(255),
                place_of_supply VARCHAR(100),
                description TEXT,
                currency VARCHAR(3) DEFAULT 'INR',
                base_amount DECIMAL(15, 2) DEFAULT 0,
                tax_rate DECIMAL(5, 2) DEFAULT 18,
                sgst DECIMAL(15, 2) DEFAULT 0,
                cgst DECIMAL(15, 2) DEFAULT 0,
                igst DECIMAL(15, 2) DEFAULT 0,
                total_amount DECIMAL(15, 2) DEFAULT 0,
                tds_amount DECIMAL(15, 2) DEFAULT 0,
                net_amount DECIMAL(15, 2) DEFAULT 0,
                received DECIMAL(15, 2) DEFAULT 0,
                pending_amount DECIMAL(15, 2) DEFAULT 0,
                payment_status ENUM('paid', 'unpaid', 'cancelled') DEFAULT 'unpaid',
                approval_status ENUM('created', 'requested', 'final_approved') DEFAULT 'created',
                payment_due_date DATE,
                bank_name TEXT,
                bank_account_no VARCHAR(100),
                bank_ifsc VARCHAR(50),
                account_holder TEXT,
                amount_in_words TEXT,
                terms_conditions TEXT,
                authorized_signatory VARCHAR(255),
                remarks TEXT,
                items JSON,
                requested_at DATETIME NULL,
                requested_by VARCHAR(50) NULL,
                approved_at DATETIME NULL,
                approved_by VARCHAR(50) NULL,
                signature_data TEXT NULL,
                signed_at DATETIME NULL,
                signed_pdf LONGTEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
                INDEX idx_user_id (user_id),
                INDEX idx_client_id (client_id),
                INDEX idx_invoice_number (invoice_number),
                INDEX idx_date (date),
                INDEX idx_payment_status (payment_status),
                INDEX idx_approval_status (approval_status)
            )
        `);

        // Create Banks Table
        await promiseDb.execute(`
            CREATE TABLE IF NOT EXISTS banks (
                id VARCHAR(50) PRIMARY KEY,
                bank_name VARCHAR(255) NOT NULL,
                account_number VARCHAR(50) NOT NULL UNIQUE,
                ifsc_code VARCHAR(20) NOT NULL,
                account_holder VARCHAR(255) NOT NULL,
                branch VARCHAR(255),
                is_default BOOLEAN DEFAULT FALSE,
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_by VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
                INDEX idx_account_number (account_number),
                INDEX idx_branch (branch),
                INDEX idx_is_default (is_default),
                INDEX idx_status (status)
            )
        `);

        // Create Tax Settings Table
        await promiseDb.execute(`
            CREATE TABLE IF NOT EXISTS tax_settings (
                id VARCHAR(50) PRIMARY KEY,
                tax_name VARCHAR(100) NOT NULL,
                tax_rate DECIMAL(5, 2) NOT NULL,
                is_default BOOLEAN DEFAULT FALSE,
                applicable_from DATE,
                applicable_to DATE,
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_by VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_is_default (is_default),
                INDEX idx_status (status)
            )
        `);

        // Create State Mapping Table
        await promiseDb.execute(`
            CREATE TABLE IF NOT EXISTS state_mapping (
                code VARCHAR(2) PRIMARY KEY,
                name VARCHAR(100) NOT NULL
            )
        `);

        console.log('✅ Database tables initialized successfully');
        
        // Migrate existing data: Convert partial/overdue to unpaid
        await promiseDb.execute(`
            UPDATE invoices 
            SET payment_status = 'unpaid' 
            WHERE payment_status IN ('partial', 'overdue')
        `);
        console.log('✅ Migrated existing partial/overdue invoices to unpaid status');
        
        // Migrate existing invoices to populate created_by_name
        const [result] = await promiseDb.execute(`
            UPDATE invoices i
            JOIN users u ON i.user_id = u.id
            SET i.created_by_name = u.full_name
            WHERE i.created_by_name IS NULL OR i.created_by_name = ''
        `);
        console.log(`✅ Updated ${result.affectedRows} invoices with creator names`);
        
        // Insert default tax settings if none exist
        const [taxCount] = await promiseDb.execute('SELECT COUNT(*) as count FROM tax_settings');
        if (taxCount[0].count === 0) {
            await promiseDb.execute(`
                INSERT INTO tax_settings (id, tax_name, tax_rate, is_default, applicable_from, status) VALUES
                (UUID(), 'GST', 18, 1, CURDATE(), 'active'),
                (UUID(), 'GST', 12, 0, CURDATE(), 'active'),
                (UUID(), 'GST', 5, 0, CURDATE(), 'active'),
                (UUID(), 'GST', 0, 0, CURDATE(), 'active')
            `);
            console.log('✅ Default tax settings inserted');
        }
        
        // Insert default bank accounts if none exist
        const [bankCount] = await promiseDb.execute('SELECT COUNT(*) as count FROM banks');
        if (bankCount[0].count === 0) {
            await promiseDb.execute(`
                INSERT INTO banks (id, bank_name, account_number, ifsc_code, account_holder, branch, is_default) VALUES
                (UUID(), 'AXIS BANK LIMITED', '922020060131840', 'UTIB0000425', 'JAYARAMA ASSOCIATES', 'Sanath Nagar, Hyderabad', 1),
                (UUID(), 'STATE BANK OF INDIA', '38406950654', 'SBIN0005094', 'JAYARAMA ASSOCIATES', 'Czech Colony, Sanath Nagar', 0),
                (UUID(), 'HDFC BANK', '50100123456789', 'HDFC0001234', 'JAYARAMA ASSOCIATES', 'Banjara Hills, Hyderabad', 0)
            `);
            console.log('✅ Default bank accounts inserted');
        }
        
        // Insert default state mapping if none exist
        const [stateCount] = await promiseDb.execute('SELECT COUNT(*) as count FROM state_mapping');
        if (stateCount[0].count === 0) {
            await promiseDb.execute(`
                INSERT INTO state_mapping (code, name) VALUES 
                ('36', 'Telangana'),
                ('37', 'Andhra Pradesh')
            `);
            console.log('✅ Default state mapping inserted');
        }
        
        // Insert sample clients if none exist
        const [clientCount] = await promiseDb.execute('SELECT COUNT(*) as count FROM clients');
        if (clientCount[0].count === 0) {
            await promiseDb.execute(`
                INSERT INTO clients (id, name, address, branch, gst_number, phone, email) VALUES
                (UUID(), 'POLA SANDEEP REDDY', 'Plot No:- 12, Road No:- 1A, Czech Colony, sanath Nagar', 'Sanath Nagar, Hyderabad', '36LUAPS9179K1Z', '7286997507', 'sandeep@example.com'),
                (UUID(), 'Axis Bank', '8-17, opposite railway station, giddalur', 'Giddalur, Prakasam District', '37LUAPS9179K1Z', '07286997507', 'axisbank@example.com'),
                (UUID(), 'DCB BANK LIMITED', '8-2-120/84, II FLOOR, JYOTHI MAJESTIC, ROAD NO.2, BANJARA HILLS', 'Banjara Hills, Hyderabad', '36AAACD1461F1Z3', '02268997777', 'dcb@example.com')
            `);
            console.log('✅ Sample clients inserted');
        }
        
        // Ensure first user is super_admin if no users exist
        const [userCount] = await promiseDb.execute('SELECT COUNT(*) as count FROM users');
        if (userCount[0].count > 0) {
            const [firstUser] = await promiseDb.execute('SELECT id, role FROM users ORDER BY created_at ASC LIMIT 1');
            if (firstUser[0] && firstUser[0].role === 'admin') {
                await promiseDb.execute('UPDATE users SET role = "super_admin" WHERE id = ?', [firstUser[0].id]);
                console.log('✅ First user promoted to super_admin');
            }
        }
        
    } catch (error) {
        console.error('❌ Database initialization error:', error);
        throw error;
    }
}

// JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, process.env.JWT_SECRET || 'your_secret_key', (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
};

const authorizeAdmin = (req, res, next) => {
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        return res.status(403).json({ error: 'Access denied. Admin privileges required.' });
    }
    next();
};

const authorizeSuperAdmin = (req, res, next) => {
    if (req.user.role !== 'super_admin') {
        return res.status(403).json({ error: 'Access denied. Super Admin privileges required.' });
    }
    next();
};

// ============= AUTH ROUTES =============

// Send OTP to ADMIN email
app.post('/api/auth/send-otp', async (req, res) => {
    const { adminEmail, userEmail, fullName, username } = req.body;
    
    if (!adminEmail || !userEmail) {
        return res.status(400).json({ success: false, message: 'Admin email and user email are required' });
    }
    
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000;
    
    otpStore.set(adminEmail, { otp, expiresAt, attempts: 0, userEmail, fullName, username });
    
    try {
        const mailOptions = {
            from: '"JAYARAMA Invoice Manager" <noreply@jayarama.com>',
            to: adminEmail,
            subject: `🔐 New Registration Request - OTP for ${userEmail}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #0072bc;">New User Registration Request</h2>
                    <div style="background-color: #f0f0f0; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">User Details:</h3>
                        <p><strong>👤 Full Name:</strong> ${fullName || 'Not provided'}</p>
                        <p><strong>🏷️ Username:</strong> ${username || 'Not provided'}</p>
                        <p><strong>📧 Email:</strong> ${userEmail}</p>
                    </div>
                    <p>Please use the following OTP to verify this registration request:</p>
                    <div style="background-color: #f4f4f4; padding: 15px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 5px; margin: 20px 0;">
                        ${otp}
                    </div>
                    <p>⏰ This OTP is valid for 10 minutes.</p>
                    <hr>
                    <p style="font-size: 12px; color: #666;">This is an automated message from JAYARAMA Invoice Manager</p>
                </div>
            `
        };
        
        await transporter.sendMail(mailOptions);
        res.json({ success: true, message: 'Registration request sent to administrator' });
    } catch (error) {
        console.error('Error sending OTP:', error);
        res.status(500).json({ success: false, message: 'Failed to send registration request' });
    }
});

// Verify OTP
app.post('/api/auth/verify-otp', async (req, res) => {
    const { adminEmail, otp, userEmail } = req.body;
    
    if (!adminEmail || !otp) {
        return res.status(400).json({ success: false, message: 'Admin email and OTP are required' });
    }
    
    const storedData = otpStore.get(adminEmail);
    
    if (!storedData) {
        return res.status(400).json({ success: false, message: 'OTP not found. Please request a new registration.' });
    }
    
    if (storedData.attempts >= 5) {
        otpStore.delete(adminEmail);
        return res.status(400).json({ success: false, message: 'Too many failed attempts. Please request a new OTP.' });
    }
    
    if (Date.now() > storedData.expiresAt) {
        otpStore.delete(adminEmail);
        return res.status(400).json({ success: false, message: 'OTP has expired. Please request a new OTP.' });
    }
    
    if (storedData.otp !== otp) {
        storedData.attempts++;
        otpStore.set(adminEmail, storedData);
        return res.status(400).json({ success: false, message: `Invalid OTP. ${5 - storedData.attempts} attempts remaining.` });
    }
    
    const verificationKey = `verified_${storedData.userEmail}`;
    otpStore.set(verificationKey, { 
        verified: true, 
        userData: {
            fullName: storedData.fullName,
            username: storedData.username,
            email: storedData.userEmail
        },
        expiresAt: Date.now() + 30 * 60 * 1000
    });
    
    otpStore.delete(adminEmail);
    
    res.json({ success: true, message: 'OTP verified successfully' });
});

// Signup endpoint
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { fullName, username, email, password, otpVerified } = req.body;

        const verificationKey = `verified_${email}`;
        const verificationData = otpStore.get(verificationKey);
        
        if (!otpVerified || !verificationData || !verificationData.verified) {
            return res.status(400).json({ error: 'Please get admin approval with OTP first' });
        }
        
        if (verificationData.userData.email !== email || 
            verificationData.userData.username !== username ||
            verificationData.userData.fullName !== fullName) {
            return res.status(400).json({ error: 'Registration data mismatch. Please restart the registration process.' });
        }

        if (Date.now() > verificationData.expiresAt) {
            otpStore.delete(verificationKey);
            return res.status(400).json({ error: 'Verification has expired. Please request a new OTP from admin.' });
        }

        if (!fullName || !username || !email || !password) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (fullName.trim().length < 3) {
            return res.status(400).json({ error: 'Full name must be at least 3 characters' });
        }

        if (!validateUsername(username)) {
            return res.status(400).json({ 
                error: 'Username must start with a capital letter, followed by letters, numbers, or symbols' 
            });
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({ error: 'Please enter a valid email address' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        const [existingUsername] = await promiseDb.execute(
            'SELECT id FROM users WHERE username = ?',
            [username]
        );

        if (existingUsername.length > 0) {
            return res.status(400).json({ error: 'Username already taken' });
        }

        const [existingEmail] = await promiseDb.execute(
            'SELECT id FROM users WHERE email = ?',
            [email]
        );

        if (existingEmail.length > 0) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        const [userCount] = await promiseDb.execute('SELECT COUNT(*) as count FROM users');
        const role = userCount[0].count === 0 ? 'super_admin' : 'user';

        const hashedPassword = await bcrypt.hash(password, 10);
        const userId = `u_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        await promiseDb.execute(
            'INSERT INTO users (id, full_name, username, email, password, role) VALUES (?, ?, ?, ?, ?, ?)',
            [userId, fullName.trim(), username.trim(), email.trim(), hashedPassword, role]
        );

        otpStore.delete(verificationKey);

        const token = jwt.sign(
            { id: userId, email: email, username: username, role: role, full_name: fullName.trim() },
            process.env.JWT_SECRET || 'your_secret_key',
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            token,
            user: { 
                id: userId, 
                full_name: fullName.trim(),
                username: username.trim(),
                email: email.trim(), 
                role: role 
            }
        });
    } catch (error) {
        console.error('Signup error:', error);
        res.status(500).json({ error: 'Internal server error: ' + error.message });
    }
});

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const [users] = await promiseDb.execute(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const user = users[0];
        const isValidPassword = await bcrypt.compare(password, user.password);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, username: user.username, role: user.role, full_name: user.full_name },
            process.env.JWT_SECRET || 'your_secret_key',
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            token,
            user: { 
                id: user.id, 
                full_name: user.full_name,
                username: user.username,
                email: user.email, 
                role: user.role 
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get current user endpoint
app.get('/api/auth/me', authenticateToken, async (req, res) => {
    try {
        const [users] = await promiseDb.execute(
            'SELECT id, full_name, username, email, role FROM users WHERE id = ?',
            [req.user.id]
        );
        
        if (users.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        res.json(users[0]);
    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Verify super admin credentials for critical operations
app.post('/api/auth/verify-super-admin', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password are required' });
        }

        // Find user by username or email
        const [users] = await promiseDb.execute(
            'SELECT id, username, email, password, role FROM users WHERE (username = ? OR email = ?) AND role = ?',
            [username, username, 'super_admin']
        );

        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials or insufficient privileges' });
        }

        const user = users[0];

        // Verify password
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        res.json({ success: true, message: 'Super admin credentials verified' });
    } catch (error) {
        console.error('Super admin verification error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/// ============= eSign APPROVAL WORKFLOW ROUTES =============

// Request eSign approval (Admin only)
app.post('/api/invoices/:id/request-esign', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const invoiceId = req.params.id;
        
        const [invoices] = await promiseDb.execute(
            'SELECT approval_status FROM invoices WHERE id = ?',
            [invoiceId]
        );
        
        if (invoices.length === 0) {
            return res.status(404).json({ error: 'Invoice not found' });
        }
        
        if (invoices[0].approval_status !== 'created') {
            return res.status(400).json({ error: 'Invoice already requested or approved' });
        }
        
        await promiseDb.execute(
            `UPDATE invoices 
             SET approval_status = 'requested',
                 requested_at = NOW(),
                 requested_by = ?
             WHERE id = ?`,
            [req.user.id, invoiceId]
        );
        
        console.log(`✅ Invoice ${invoiceId} eSign approval requested by Admin ${req.user.email}`);
        
        res.json({ 
            success: true, 
            message: 'eSign approval requested successfully',
            status: 'requested'
        });
    } catch (error) {
        console.error('Request eSign error:', error);
        res.status(500).json({ error: 'Failed to request eSign approval: ' + error.message });
    }
});

// 🔥 SIGN INVOICE API (CloudSigner integration)
app.post('/api/invoices/:id/esign', authenticateToken, authorizeSuperAdmin, async (req, res) => {
    try {
        const invoiceId = req.params.id;

        // Check CloudSigner configuration
        if (!CLOUDSIGNER_URL || !CLOUDSIGNER_API_KEY || !CLOUDSIGNER_CERTIFICATE_ID) {
            return res.status(500).json({
                error: 'CloudSigner is not configured. Please check .env file.'
            });
        }

        // Get invoice from database
        const [rows] = await promiseDb.execute(
            'SELECT * FROM invoices WHERE id = ?',
            [invoiceId]
        );

        if (!rows.length) {
            return res.status(404).json({ error: 'Invoice not found' });
        }

        const invoice = rows[0];

        // Check approval status
        if (invoice.approval_status !== 'requested') {
            return res.status(400).json({ 
                error: `Invoice must be in "requested" state before CloudSigner approval. Current status: ${invoice.approval_status}`
            });
        }

        // Parse items if needed
        let items = [];
        try {
            items = typeof invoice.items === 'string' ? JSON.parse(invoice.items) : (invoice.items || []);
        } catch (e) {
            items = [];
        }

        // Prepare invoice data for PDF generation
        const invoiceData = {
            ...invoice,
            items: items,
            signature_data: invoice.signature_data,
            client_name: invoice.client_name || 'N/A',
            client_address: invoice.client_address || 'N/A',
            client_gst: invoice.client_gst || 'N/A',
            client_branch: invoice.client_branch || 'N/A',
            place_of_supply: invoice.place_of_supply || '36-Telangana',
            invoice_number: invoice.invoice_number || 'N/A',
            date: invoice.date ? new Date(invoice.date).toLocaleDateString('en-IN') : 'N/A',
            payment_due_date: invoice.payment_due_date || 'N/A',
            tds_amount: parseFloat(invoice.tds_amount) || 0,
            received: parseFloat(invoice.received) || 0,
            bank_name: invoice.bank_name || 'AXIS BANK LIMITED',
            bank_account_no: invoice.bank_account_no || '922020060131840',
            bank_ifsc: invoice.bank_ifsc || 'UTIB0000425',
            account_holder: invoice.account_holder || 'JAYARAMA ASSOCIATES',
            terms_conditions: invoice.terms_conditions || 'Thanks for doing business with us!',
            authorized_signatory: invoice.authorized_signatory || 'JAYARAMA ASSOCIATES',
            tax_rate: parseFloat(invoice.tax_rate) || 18,
            base_amount: parseFloat(invoice.base_amount) || 0,
            sgst: parseFloat(invoice.sgst) || 0,
            cgst: parseFloat(invoice.cgst) || 0,
            igst: parseFloat(invoice.igst) || 0,
            total_amount: parseFloat(invoice.total_amount) || 0,
            net_amount: parseFloat(invoice.net_amount) || 0,
            company_logo: "http://localhost:3000/JAYARAMA%20LOGO1.png"
        };

        console.log(`📄 Generating HTML invoice PDF for invoice ${invoiceData.invoice_number}...`);

        const invoiceHTML = buildInvoiceHTML(invoiceData);
        const outputPath = path.join(tempDir, `invoice-${invoiceId}-${Date.now()}.pdf`);
        await generateInvoicePDF(invoiceHTML, outputPath);
        const pdfBuffer = fs.readFileSync(outputPath);
        if (fs.existsSync(outputPath)) {
            fs.unlinkSync(outputPath);
        }

        const base64PDF = pdfBuffer.toString('base64');
        console.log(`✅ PDF generated via Puppeteer, size: ${Math.round(pdfBuffer.length / 1024)} KB`);

        console.log(`📡 Calling CloudSigner for invoice ${invoice.invoice_number}...`);

        // Prepare CloudSigner payload
        const cloudSignerPayload = {
            request_id: `inv_${invoiceId}_${Date.now()}`,
            request_ts: new Date().toISOString(),
            api_key: CLOUDSIGNER_API_KEY,
            certificate_id: CLOUDSIGNER_CERTIFICATE_ID,
            action: "sign",
            page: "1",
            location: [450, 700, 180, 70],  // Move to bottom right
            enableltv: "false",
            enablegreentick: "true",
            invisiblesignature: "false",
            lock: "false",
            ts: "false",
            options: {
                reason: `Approved by Super Admin for Invoice ${invoice.invoice_number}`,
                locations: "Digital Signature",
                customtext: `Digitally Signed - ${new Date().toLocaleString()}`
            },
            data: base64PDF
        };
        

        console.log('📤 Sending to CloudSigner...');

        // Call CloudSigner API
        const cloudSignerResponse = await axios.post(CLOUDSIGNER_URL, cloudSignerPayload, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 60000
        });

        if (!cloudSignerResponse.data || !cloudSignerResponse.data.pdf) {
            console.error('CloudSigner Error Response:', cloudSignerResponse.data);
            return res.status(500).json({
                error: "CloudSigner signing failed - No PDF returned",
                details: cloudSignerResponse.data
            });
        }

        console.log('✅ CloudSigner signed successfully!');

      
       // In the CloudSigner endpoint, change this:
        // After CloudSigner API call succeeds
const signedPdfBase64 = cloudSignerResponse.data.pdf;
console.log(`💾 Signed PDF stored in database, size: ${Math.round(signedPdfBase64.length / 1024)} KB`);

// Extract signature URL from CloudSigner response (if available)
const signatureUrl = cloudSignerResponse.data.signature_url || 
                     cloudSignerResponse.data.image_url || 
                     cloudSignerResponse.data.digital_signature_url || 
                     null;

// Update invoice in database
const signedPdfBuffer = Buffer.from(signedPdfBase64, 'base64');

await promiseDb.execute(`
    UPDATE invoices
    SET approval_status = 'final_approved',
        signature_data = 'CloudSigner_Digital_Signature',
        cloud_signer_signature_url = ?,
        signed_at = NOW(),
        signed_pdf = ?,
        approved_at = NOW(),
        approved_by = ?
    WHERE id = ?
`, [signatureUrl, signedPdfBuffer, req.user.id, invoiceId]);

console.log(`✅ CloudSigner signature URL stored: ${signatureUrl || 'Not provided by CloudSigner'}`);

        // Return success response
        res.json({
            success: true,
            message: "Invoice signed successfully with CloudSigner",
            invoice_id: invoiceId,
            invoice_number: invoice.invoice_number,
            signed_by: "CloudSigner Digital Certificate",
            serial_number: cloudSignerResponse.data.serialnumber || CLOUDSIGNER_CERTIFICATE_ID,
            download_url: `/api/invoices/${invoiceId}/download-signed-pdf`
        });

    } catch (error) {
        console.error('CloudSigner Error Details:', {
            message: error.message,
            response: error.response?.data,
            status: error.response?.status
        });
        
        let errorMessage = "Signing failed: ";
        if (error.code === 'ECONNREFUSED') {
            errorMessage += "CloudSigner service is not running. Please start it with: systemctl start cloudsigner";
        } else if (error.response?.data?.errorMessage) {
            errorMessage += error.response.data.errorMessage;
        } else {
            errorMessage += error.message;
        }
        
        res.status(500).json({ 
            error: errorMessage,
            details: error.response?.data || error.message
        });
    }
});

// Final eSign approval (Super Admin only) - Manual signature
app.post('/api/invoices/:id/final-esign', authenticateToken, authorizeSuperAdmin, async (req, res) => {
    try {
        const invoiceId = req.params.id;
        const { signature_data, signed_at } = req.body;
        
        if (!signature_data) {
            return res.status(400).json({ error: 'Signature data is required' });
        }
        
        const [invoices] = await promiseDb.execute(
            'SELECT approval_status FROM invoices WHERE id = ?',
            [invoiceId]
        );
        
        if (invoices.length === 0) {
            return res.status(404).json({ error: 'Invoice not found' });
        }
        
        if (invoices[0].approval_status !== 'requested') {
            return res.status(400).json({ error: 'Invoice not in requested state' });
        }
        
        let formattedDateTime = null;
        if (signed_at) {
            const date = new Date(signed_at);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        } else {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        }
        
        // Correct SQL - NO JavaScript comment inside the string!
        await promiseDb.execute(
            `UPDATE invoices 
             SET approval_status = 'final_approved',
                 approved_at = NOW(),
                 approved_by = ?,
                 signature_data = ?,
                 signed_at = ?
             WHERE id = ?`,
            [req.user.id, signature_data, formattedDateTime, invoiceId]
        );
        
        console.log(`✅ Invoice ${invoiceId} final approved by Super Admin ${req.user.email}`);
        
        res.json({ 
            success: true, 
            message: 'Invoice final approved with eSign',
            status: 'final_approved'
        });
    } catch (error) {
        console.error('Final eSign error:', error);
        res.status(500).json({ error: 'Failed to final approve invoice: ' + error.message });
    }
});

// Legacy PDF routes removed. Use /api/invoice/generate-pdf instead.

// ============= INVOICE ROUTES =============

app.get('/api/invoices/next-number', authenticateToken, async (req, res) => {
    try {
        const currentFY = getFinancialYear();
        
        const [lastInvoice] = await promiseDb.execute(
            `SELECT invoice_number, created_at FROM invoices 
             ORDER BY created_at DESC LIMIT 1`
        );
        
        let nextSerial = 1;
        let previousNumber = null;
        
        if (lastInvoice.length > 0 && lastInvoice[0].invoice_number) {
            previousNumber = lastInvoice[0].invoice_number;
            const match = previousNumber.match(/JA\/(\d{2}-\d{2})\/(\d+)/);
            
            if (match) {
                const prevFY = match[1];
                const prevSerial = parseInt(match[2]);
                
                if (prevFY === currentFY) {
                    nextSerial = prevSerial + 1;
                } else {
                    nextSerial = 1;
                }
            }
        }
        
        const formattedSerial = nextSerial.toString().padStart(3, '0');
        const invoiceNumber = `JA/${currentFY}/${formattedSerial}`;
        
        res.json({ 
            success: true,
            invoiceNumber: invoiceNumber,
            previousNumber: previousNumber || 'No previous invoice',
            nextSerial: nextSerial,
            financialYear: currentFY
        });
        
    } catch (error) {
        console.error('Generate invoice number error:', error);
        const currentFY = getFinancialYear();
        const fallbackNumber = `JA/${currentFY}/001`;
        res.json({ 
            success: false,
            invoiceNumber: fallbackNumber,
            previousNumber: 'Error occurred'
        });
    }
});

// GET all invoices
app.get('/api/invoices', authenticateToken, async (req, res) => {
    try {
        let query = `
            SELECT i.*, u.full_name as full_name,
                   c.name as client_bank_name
            FROM invoices i
            LEFT JOIN users u ON i.user_id = u.id
            LEFT JOIN clients c ON i.client_id = c.id
        `;
        let params = [];
        
        if (req.user.role === 'user') {
            query += ` WHERE i.user_id = ?`;
            params.push(req.user.id);
        }
        
        query += ` ORDER BY i.created_at DESC`;
        
        const [invoices] = await promiseDb.execute(query, params);

        console.log(`User ${req.user.email} (${req.user.role}) fetched ${invoices.length} invoices`);

        const parsedInvoices = invoices.map(invoice => {
            let items = [];
            try {
                items = typeof invoice.items === 'string' ? JSON.parse(invoice.items) : (invoice.items || []);
            } catch (e) {
                items = [];
            }
            
            let dateString = null;
            if (invoice.date) {
                if (invoice.date instanceof Date) {
                    const year = invoice.date.getFullYear();
                    const month = String(invoice.date.getMonth() + 1).padStart(2, '0');
                    const day = String(invoice.date.getDate()).padStart(2, '0');
                    dateString = `${year}-${month}-${day}`;
                } else {
                    const dateStr = String(invoice.date);
                    if (dateStr.match(/^\d{4}-\d{2}-\d{2}/)) {
                        dateString = dateStr.split('T')[0].split(' ')[0];
                    } else {
                        dateString = dateStr;
                    }
                }
            }
            
            return {
                ...invoice,
                items: items,
                date: dateString
            };
        });

        res.json(parsedInvoices);
    } catch (error) {
        console.error('Get invoices error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET single invoice
app.get('/api/invoices/:id', authenticateToken, async (req, res) => {
    try {
        const query = `
            SELECT i.*, u.full_name as full_name 
            FROM invoices i
            LEFT JOIN users u ON i.user_id = u.id
            WHERE i.id = ?
        `;
        const [invoices] = await promiseDb.execute(query, [req.params.id]);

        if (invoices.length === 0) {
            return res.status(404).json({ error: 'Invoice not found' });
        }

        const invoice = invoices[0];
        
        let items = [];
        try {
            items = typeof invoice.items === 'string' ? JSON.parse(invoice.items) : (invoice.items || []);
        } catch (e) {
            items = [];
        }
        
        let dateString = null;
        if (invoice.date) {
            if (invoice.date instanceof Date) {
                const year = invoice.date.getFullYear();
                const month = String(invoice.date.getMonth() + 1).padStart(2, '0');
                const day = String(invoice.date.getDate()).padStart(2, '0');
                dateString = `${year}-${month}-${day}`;
            } else {
                dateString = String(invoice.date).split('T')[0];
            }
        }

        res.json({
            ...invoice,
            items: items,
            date: dateString
        });
    } catch (error) {
        console.error('Get invoice error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// CREATE or UPDATE invoice
app.post('/api/invoices', authenticateToken, async (req, res) => {
    try {
        const invoice = req.body;
        
        const [userInfo] = await promiseDb.execute(
            'SELECT full_name FROM users WHERE id = ?',
            [req.user.id]
        );
        const createdByName = userInfo.length > 0 ? userInfo[0].full_name : req.user.full_name || 'Unknown';
        
        if (!invoice.id) {
            const [existing] = await promiseDb.execute(
                'SELECT id FROM invoices WHERE invoice_number = ?',
                [invoice.invoice_number]
            );
            
            if (existing.length > 0) {
                return res.status(400).json({ 
                    error: 'Invoice number already exists! Please refresh the page to get a new number.' 
                });
            }
            invoice.id = `inv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }
        
        invoice.user_id = req.user.id;
        
        let mysqlDate = null;
        if (invoice.date) {
            if (invoice.date.match(/^\d{4}-\d{2}-\d{2}$/)) {
                mysqlDate = invoice.date;
            } 
            else if (invoice.date.match(/^\d{2}-\d{2}-\d{4}$/)) {
                const [day, month, year] = invoice.date.split('-');
                mysqlDate = `${year}-${month}-${day}`;
            }
            else if (invoice.date instanceof Date) {
                const year = invoice.date.getFullYear();
                const month = String(invoice.date.getMonth() + 1).padStart(2, '0');
                const day = String(invoice.date.getDate()).padStart(2, '0');
                mysqlDate = `${year}-${month}-${day}`;
            }
            else {
                const parsedDate = new Date(invoice.date);
                if (!isNaN(parsedDate.getTime())) {
                    const year = parsedDate.getFullYear();
                    const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
                    const day = String(parsedDate.getDate()).padStart(2, '0');
                    mysqlDate = `${year}-${month}-${day}`;
                }
            }
        }
        
        if (!mysqlDate) {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            mysqlDate = `${year}-${month}-${day}`;
        }
        
        let baseAmount = 0;
        const items = invoice.items || [];
        items.forEach(item => {
            const price = parseFloat(item.price) || 0;
            const quantity = parseFloat(item.quantity) || 0;
            baseAmount += price * quantity;
        });
        
        let supplyLocation = invoice.client_state || invoice.place_of_supply || DEFAULT_PLACE_OF_SUPPLY;
        const taxRate = invoice.tax_rate || DEFAULT_TAX_RATE;
        
        const taxCalculations = calculateTaxAmounts(baseAmount, supplyLocation, taxRate);
        
        const tdsAmount = invoice.tds_amount || 0;
        const netAmount = taxCalculations.totalAmount - tdsAmount;
        const received = invoice.received || 0;
        const pendingAmount = netAmount - received;
        
        let paymentStatus = invoice.payment_status || 'unpaid';
        const allowedStatuses = ['paid', 'unpaid', 'cancelled'];
        
        if (!allowedStatuses.includes(paymentStatus)) {
            paymentStatus = 'unpaid';
        }
        
        if (pendingAmount <= 0 && paymentStatus !== 'cancelled') {
            paymentStatus = 'paid';
        }
        
        const amountInWords = convertToWords(taxCalculations.totalAmount);
        const itemsJson = JSON.stringify(items);
        
        const bankName = invoice.bank_name || 'AXIS BANK LIMITED';
        const bankAccountNo = invoice.bank_account_no || '922020060131840';
        const bankIfsc = invoice.bank_ifsc || 'UTIB0000425';
        const accountHolder = invoice.account_holder || 'JAYARAMA ASSOCIATES';
        const businessName = invoice.business_name || DEFAULT_BUSINESS_NAME;
        const businessAddress = invoice.business_address || DEFAULT_BUSINESS_ADDRESS;
        const termsConditions = invoice.terms_conditions || 'Thanks for doing business with us!';
        const authorizedSignatory = invoice.authorized_signatory || 'JAYARAMA ASSOCIATES';
        
        const clientId = invoice.client_id || null;
        const clientName = invoice.client_name || null;
        const clientAddress = invoice.client_address || null;
        const clientBranch = invoice.client_branch || null;
        const clientGst = invoice.client_gst || null;
        const clientPhone = invoice.client_phone || null;
        const clientEmail = invoice.client_email || null;
        const description = invoice.description || null;
        const currency = invoice.currency || 'INR';
        const paymentDueDate = invoice.payment_due_date || null;
        const remarks = invoice.remarks || null;
        const placeOfSupplyToSave = invoice.place_of_supply || supplyLocation;
        
        let approvalStatus = invoice.approval_status || 'created';
        
        const [existingInvoice] = await promiseDb.execute(
            'SELECT id FROM invoices WHERE id = ?',
            [invoice.id]
        );
        
        if (existingInvoice.length > 0) {
            await promiseDb.execute(
                `UPDATE invoices SET
                    invoice_number = ?, date = ?,
                    business_name = ?, business_address = ?,
                    client_id = ?, client_name = ?, client_address = ?, client_branch = ?,
                    client_gst = ?, client_phone = ?, client_email = ?,
                    place_of_supply = ?, description = ?, currency = ?,
                    base_amount = ?, tax_rate = ?, sgst = ?, cgst = ?, igst = ?,
                    total_amount = ?, tds_amount = ?, net_amount = ?,
                    received = ?, pending_amount = ?, payment_status = ?,
                    approval_status = ?,
                    payment_due_date = ?, bank_name = ?, bank_account_no = ?,
                    bank_ifsc = ?, account_holder = ?, amount_in_words = ?,
                    terms_conditions = ?, authorized_signatory = ?, remarks = ?,
                    items = ?, created_by_name = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?`,
                [
                    invoice.invoice_number, mysqlDate,
                    businessName, businessAddress,
                    clientId, clientName, clientAddress, clientBranch,
                    clientGst, clientPhone, clientEmail,
                    placeOfSupplyToSave, description, currency,
                    baseAmount, taxRate, taxCalculations.sgst, taxCalculations.cgst, taxCalculations.igst,
                    taxCalculations.totalAmount, tdsAmount, netAmount,
                    received, pendingAmount, paymentStatus,
                    approvalStatus,
                    paymentDueDate, bankName, bankAccountNo,
                    bankIfsc, accountHolder, amountInWords, termsConditions,
                    authorizedSignatory, remarks, itemsJson,
                    createdByName,
                    invoice.id
                ]
            );
            console.log('✅ Updated existing invoice:', invoice.id);
        } else {
            await promiseDb.execute(
                `INSERT INTO invoices (
                    id, user_id, created_by_name, invoice_number, date,
                    business_name, business_address,
                    client_id, client_name, client_address, client_branch,
                    client_gst, client_phone, client_email,
                    place_of_supply, description, currency,
                    base_amount, tax_rate, sgst, cgst, igst,
                    total_amount, tds_amount, net_amount,
                    received, pending_amount, payment_status,
                    approval_status,
                    payment_due_date, bank_name, bank_account_no,
                    bank_ifsc, account_holder, amount_in_words,
                    terms_conditions, authorized_signatory, remarks,
                    items, requested_at, requested_by, approved_at, 
                    approved_by, signature_data, signed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    invoice.id, 
                    invoice.user_id, 
                    createdByName, 
                    invoice.invoice_number, 
                    mysqlDate,
                    businessName, 
                    businessAddress,
                    clientId, 
                    clientName, 
                    clientAddress, 
                    clientBranch,
                    clientGst, 
                    clientPhone, 
                    clientEmail,
                    placeOfSupplyToSave, 
                    description, 
                    currency,
                    baseAmount, 
                    taxRate, 
                    taxCalculations.sgst, 
                    taxCalculations.cgst, 
                    taxCalculations.igst,
                    taxCalculations.totalAmount, 
                    tdsAmount, 
                    netAmount,
                    received, 
                    pendingAmount, 
                    paymentStatus,
                    approvalStatus,
                    paymentDueDate, 
                    bankName, 
                    bankAccountNo,
                    bankIfsc, 
                    accountHolder, 
                    amountInWords, 
                    termsConditions,
                    authorizedSignatory, 
                    remarks, 
                    itemsJson,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
                ]
            );
            console.log('✅ Created new invoice:', invoice.id);
        }

        res.json({ 
            success: true, 
            id: invoice.id, 
            message: 'Invoice saved successfully',
            calculations: {
                baseAmount,
                sgst: taxCalculations.sgst,
                cgst: taxCalculations.cgst,
                igst: taxCalculations.igst,
                totalAmount: taxCalculations.totalAmount,
                netAmount,
                pendingAmount,
                paymentStatus,
                approvalStatus
            }
        });
    } catch (error) {
        console.error('Save invoice error:', error);
        res.status(500).json({ error: 'Internal server error: ' + error.message });
    }
});

// DELETE invoice - ADMIN only
app.delete('/api/invoices/:id', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const [result] = await promiseDb.execute(
            'DELETE FROM invoices WHERE id = ?',
            [req.params.id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Invoice not found' });
        }

        res.json({ success: true, message: 'Invoice deleted successfully' });
    } catch (error) {
        console.error('Delete invoice error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ============= REPORT ROUTES =============

app.get('/api/reports/invoice-summary', authenticateToken, async (req, res) => {
    try {
        const { start_date, end_date, payment_status } = req.query;
        
        let query = `
            SELECT 
                DATE(date) as invoice_date,
                invoice_number,
                client_name,
                client_branch,
                client_gst,
                base_amount,
                sgst,
                cgst,
                igst,
                total_amount,
                tds_amount,
                net_amount,
                received,
                pending_amount,
                payment_status,
                approval_status,
                payment_due_date
            FROM invoices
            WHERE 1=1
        `;
        let params = [];
        
        if (start_date) {
            query += ` AND date >= ?`;
            params.push(start_date);
        }
        
        if (end_date) {
            query += ` AND date <= ?`;
            params.push(end_date);
        }
        
        if (payment_status && payment_status !== 'all') {
            query += ` AND payment_status = ?`;
            params.push(payment_status);
        }
        
        if (req.user.role === 'user') {
            query += ` AND user_id = ?`;
            params.push(req.user.id);
        }
        
        query += ` ORDER BY date DESC`;
        
        const [reports] = await promiseDb.execute(query, params);
        res.json(reports);
    } catch (error) {
        console.error('Report error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/reports/monthly-summary', authenticateToken, async (req, res) => {
    try {
        let query = `
            SELECT 
                DATE_FORMAT(date, '%Y-%m') as month,
                COUNT(*) as invoice_count,
                SUM(base_amount) as total_base_amount,
                SUM(sgst) as total_sgst,
                SUM(cgst) as total_cgst,
                SUM(igst) as total_igst,
                SUM(total_amount) as total_amount,
                SUM(tds_amount) as total_tds,
                SUM(net_amount) as total_net_amount,
                SUM(received) as total_received,
                SUM(pending_amount) as total_pending
            FROM invoices
            WHERE 1=1
        `;
        
        if (req.user.role === 'user') {
            query += ` AND user_id = '${req.user.id}'`;
        }
        
        query += ` GROUP BY DATE_FORMAT(date, '%Y-%m') ORDER BY month DESC`;
        
        const [reports] = await promiseDb.execute(query);
        res.json(reports);
    } catch (error) {
        console.error('Monthly summary error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ============= CLIENT ROUTES =============

app.get('/api/clients', authenticateToken, async (req, res) => {
    try {
        const [clients] = await promiseDb.execute(
            'SELECT * FROM clients ORDER BY name ASC'
        );
        res.json(clients);
    } catch (error) {
        console.error('Get clients error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/clients/:id', authenticateToken, async (req, res) => {
    try {
        const [clients] = await promiseDb.execute(
            'SELECT * FROM clients WHERE id = ?',
            [req.params.id]
        );
        
        if (clients.length === 0) {
            return res.status(404).json({ error: 'Client not found' });
        }
        
        res.json(clients[0]);
    } catch (error) {
        console.error('Get client error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/clients/branch/:branch', authenticateToken, async (req, res) => {
    try {
        const [clients] = await promiseDb.execute(
            'SELECT * FROM clients WHERE branch LIKE ? ORDER BY name ASC',
            [`%${req.params.branch}%`]
        );
        res.json(clients);
    } catch (error) {
        console.error('Get clients by branch error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/clients', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const { name, address, branch, gst_number, phone, email } = req.body;
        
        if (!name) {
            return res.status(400).json({ error: 'Client name is required' });
        }
        
        const clientId = `cl_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        await promiseDb.execute(
            `INSERT INTO clients (id, name, address, branch, gst_number, phone, email, created_by) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [clientId, name, address || null, branch || null, gst_number || null, phone || null, email || null, req.user.id]
        );
        
        res.json({ 
            success: true, 
            message: 'Client added successfully',
            client: { id: clientId, name, address, branch, gst_number, phone, email }
        });
    } catch (error) {
        console.error('Add client error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/clients/:id', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const { name, address, branch, gst_number, phone, email } = req.body;
        
        await promiseDb.execute(
            `UPDATE clients SET 
                name = ?, address = ?, branch = ?, gst_number = ?, 
                phone = ?, email = ?,
                updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [name, address || null, branch || null, gst_number || null, phone || null, email || null, req.params.id]
        );
        
        res.json({ success: true, message: 'Client updated successfully' });
    } catch (error) {
        console.error('Update client error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/clients/:id', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        await promiseDb.execute('DELETE FROM clients WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Client deleted successfully' });
    } catch (error) {
        console.error('Delete client error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ============= BANK ACCOUNT ROUTES =============

app.get('/api/banks', authenticateToken, async (req, res) => {
    try {
        const [banks] = await promiseDb.execute(
            `SELECT id, bank_name, account_number, ifsc_code, account_holder, branch, is_default, status 
             FROM banks WHERE status = "active" ORDER BY is_default DESC, bank_name ASC`
        );
        res.json(banks);
    } catch (error) {
        console.error('Get banks error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/banks/:id', authenticateToken, async (req, res) => {
    try {
        const [banks] = await promiseDb.execute(
            `SELECT id, bank_name, account_number, ifsc_code, account_holder, branch, is_default 
             FROM banks WHERE id = ? AND status = "active"`,
            [req.params.id]
        );
        
        if (banks.length === 0) {
            return res.status(404).json({ error: 'Bank account not found' });
        }
        
        res.json(banks[0]);
    } catch (error) {
        console.error('Get bank error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/banks', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const { bank_name, account_number, ifsc_code, account_holder, branch, is_default } = req.body;
        
        if (!bank_name || !account_number || !ifsc_code || !account_holder) {
            return res.status(400).json({ 
                error: 'Bank name, account number, IFSC code, and account holder are required' 
            });
        }
        
        const [existing] = await promiseDb.execute(
            'SELECT id FROM banks WHERE account_number = ?',
            [account_number]
        );
        
        if (existing.length > 0) {
            return res.status(400).json({ error: 'Account number already exists' });
        }
        
        if (is_default) {
            await promiseDb.execute('UPDATE banks SET is_default = FALSE WHERE is_default = TRUE');
        }
        
        const bankId = `bank_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        await promiseDb.execute(
            `INSERT INTO banks (id, bank_name, account_number, ifsc_code, account_holder, branch, is_default, created_by) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [bankId, bank_name, account_number, ifsc_code.toUpperCase(), account_holder, branch || null, is_default || false, req.user.id]
        );
        
        const [newBank] = await promiseDb.execute(
            `SELECT id, bank_name, account_number, ifsc_code, account_holder, branch, is_default 
             FROM banks WHERE id = ?`,
            [bankId]
        );
        
        res.status(201).json({
            success: true,
            message: 'Bank account added successfully',
            bank: newBank[0]
        });
    } catch (error) {
        console.error('Add bank error:', error);
        res.status(500).json({ error: 'Internal server error: ' + error.message });
    }
});

app.put('/api/banks/:id', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const { bank_name, account_number, ifsc_code, account_holder, branch, is_default } = req.body;
        
        const [existingBank] = await promiseDb.execute(
            'SELECT * FROM banks WHERE id = ?',
            [req.params.id]
        );
        
        if (existingBank.length === 0) {
            return res.status(404).json({ error: 'Bank account not found' });
        }
        
        if (account_number && account_number !== existingBank[0].account_number) {
            const [duplicate] = await promiseDb.execute(
                'SELECT id FROM banks WHERE account_number = ? AND id != ?',
                [account_number, req.params.id]
            );
            if (duplicate.length > 0) {
                return res.status(400).json({ error: 'Account number already exists' });
            }
        }
        
        if (is_default) {
            await promiseDb.execute('UPDATE banks SET is_default = FALSE WHERE is_default = TRUE AND id != ?', [req.params.id]);
        }
        
        await promiseDb.execute(
            `UPDATE banks 
             SET bank_name = COALESCE(?, bank_name),
                 account_number = COALESCE(?, account_number),
                 ifsc_code = COALESCE(UPPER(?), ifsc_code),
                 account_holder = COALESCE(?, account_holder),
                 branch = COALESCE(?, branch),
                 is_default = COALESCE(?, is_default),
                 updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [bank_name, account_number, ifsc_code, account_holder, branch, is_default, req.params.id]
        );
        
        const [updatedBank] = await promiseDb.execute(
            `SELECT id, bank_name, account_number, ifsc_code, account_holder, branch, is_default 
             FROM banks WHERE id = ?`,
            [req.params.id]
        );
        
        res.json({
            success: true,
            message: 'Bank account updated successfully',
            bank: updatedBank[0]
        });
    } catch (error) {
        console.error('Update bank error:', error);
        res.status(500).json({ error: 'Internal server error: ' + error.message });
    }
});

app.delete('/api/banks/:id', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const [bank] = await promiseDb.execute('SELECT * FROM banks WHERE id = ?', [req.params.id]);
        
        if (bank.length === 0) {
            return res.status(404).json({ error: 'Bank account not found' });
        }
        
        await promiseDb.execute('UPDATE banks SET status = "inactive" WHERE id = ?', [req.params.id]);
        
        res.json({ 
            success: true, 
            message: 'Bank account deleted successfully' 
        });
    } catch (error) {
        console.error('Delete bank error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.patch('/api/banks/:id/set-default', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const [bank] = await promiseDb.execute(
            'SELECT * FROM banks WHERE id = ? AND status = "active"', 
            [req.params.id]
        );
        
        if (bank.length === 0) {
            return res.status(404).json({ error: 'Bank account not found' });
        }
        
        await promiseDb.execute('UPDATE banks SET is_default = FALSE');
        await promiseDb.execute('UPDATE banks SET is_default = TRUE WHERE id = ?', [req.params.id]);
        
        const [updatedBank] = await promiseDb.execute(
            `SELECT id, bank_name, account_number, ifsc_code, account_holder, branch, is_default 
             FROM banks WHERE id = ?`,
            [req.params.id]
        );
        
        res.json({
            success: true,
            message: 'Default bank account set successfully',
            bank: updatedBank[0]
        });
    } catch (error) {
        console.error('Set default bank error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/banks/branch/:branch', authenticateToken, async (req, res) => {
    try {
        const [banks] = await promiseDb.execute(
            `SELECT id, bank_name, account_number, ifsc_code, account_holder, branch, is_default, status 
             FROM banks WHERE status = "active" AND branch LIKE ? ORDER BY bank_name ASC`,
            [`%${req.params.branch}%`]
        );
        res.json(banks);
    } catch (error) {
        console.error('Get banks by branch error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ============= TAX SETTINGS ROUTES =============

app.get('/api/tax-settings', authenticateToken, async (req, res) => {
    try {
        const [taxSettings] = await promiseDb.execute(
            'SELECT * FROM tax_settings WHERE status = "active" ORDER BY is_default DESC, tax_rate ASC'
        );
        res.json(taxSettings);
    } catch (error) {
        console.error('Get tax settings error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/tax-settings/default', authenticateToken, async (req, res) => {
    try {
        const [taxSettings] = await promiseDb.execute(
            'SELECT * FROM tax_settings WHERE is_default = 1 AND status = "active" LIMIT 1'
        );
        res.json(taxSettings[0] || { tax_rate: 18 });
    } catch (error) {
        console.error('Get default tax error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ============= STATE MAPPING ROUTES =============

app.get('/api/state-mapping', authenticateToken, async (req, res) => {
    try {
        const [stateMapping] = await promiseDb.execute(
            'SELECT code, name FROM state_mapping ORDER BY code'
        );
        res.json(stateMapping);
    } catch (error) {
        console.error('Get state mapping error:', error);
        res.json([
            { code: '36', name: 'Telangana' },
            { code: '37', name: 'Andhra Pradesh' }
        ]);
    }
});

app.post('/api/state-mapping', authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        const mapping = req.body;
        
        await promiseDb.execute('DELETE FROM state_mapping');
        
        for (const state of mapping) {
            if (state.code && state.name) {
                await promiseDb.execute(
                    'INSERT INTO state_mapping (code, name) VALUES (?, ?)',
                    [state.code, state.name]
                );
            }
        }
        
        res.json({ success: true, message: 'State mapping saved successfully' });
    } catch (error) {
        console.error('Save state mapping error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Add this NEW endpoint after the existing download-pdf endpoint
app.get('/api/invoices/:id/download-signed-pdf', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
            return res.status(403).json({ error: 'Only administrators can download invoices' });
        }

        const invoiceId = req.params.id;
        const [invoices] = await promiseDb.execute(
            'SELECT invoice_number, signed_pdf, approval_status FROM invoices WHERE id = ?',
            [invoiceId]
        );

        if (!invoices || invoices.length === 0) {
            return res.status(404).json({ error: 'Invoice not found' });
        }

        const invoice = invoices[0];
        
        if (invoice.approval_status !== 'final_approved' || !invoice.signed_pdf) {
            return res.status(400).json({ error: 'Signed PDF not available for this invoice' });
        }

        let pdfBuffer;
        
        // Handle different storage formats
        if (Buffer.isBuffer(invoice.signed_pdf)) {
            pdfBuffer = invoice.signed_pdf;
        } else if (typeof invoice.signed_pdf === 'string' && invoice.signed_pdf.startsWith('0x')) {
            pdfBuffer = Buffer.from(invoice.signed_pdf.substring(2), 'hex');
        } else if (typeof invoice.signed_pdf === 'string') {
            pdfBuffer = Buffer.from(invoice.signed_pdf, 'base64');
        } else {
            return res.status(500).json({ error: 'Invalid signed PDF format' });
        }

        // Verify it's a valid PDF
        if (pdfBuffer.slice(0, 4).toString() !== '%PDF') {
            return res.status(500).json({ error: 'Stored PDF is corrupted' });
        }

        const safeInvoiceNumber = String(invoice.invoice_number).replace(/[^a-zA-Z0-9-_]/g, '_');
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="signed_invoice_${safeInvoiceNumber}.pdf"`);
        res.send(pdfBuffer);
        
    } catch (error) {
        console.error('Download signed PDF error:', error);
        res.status(500).json({ error: 'Failed to download signed PDF: ' + error.message });
    }
});

// ============= TEST ROUTE =============

app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'API is working with CORS and eSign workflow!',
        corsEnabled: true,
        allowedOrigins: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173'],
        endpoints: {
            auth: '/api/auth/*',
            invoices: '/api/invoices/*',
            clients: '/api/clients/*',
            banks: '/api/banks/*',
            reports: '/api/reports/*',
            taxSettings: '/api/tax-settings/*',
            invoice: '/api/invoice/*',
            eSign: '/api/invoices/:id/request-esign, /api/invoices/:id/final-esign, /api/invoices/:id/download-signed-pdf'
        }
    });
});

// ============= SERVER STARTUP =============

const PORT = process.env.PORT || 5000;

// Initialize database and start server
initializeDatabase().then(() => {
    app.listen(PORT, () => {
        console.log(`\n=====================================`);
        console.log(`🚀 Server is running!`);
        console.log(`=====================================`);
        console.log(`✅ Server running on port ${PORT}`);
        console.log(`✅ CORS enabled for: http://localhost:3000, http://localhost:3001, http://localhost:5173`);
        console.log(`✅ MySQL connected successfully`);
        console.log(`✅ Puppeteer HTML-to-PDF generation enabled`);
        console.log(`\n📋 Available API Endpoints:`);
        console.log(`   🔐 AUTH:`);
        console.log(`   POST   /api/auth/send-otp - Send OTP to ADMIN email`);
        console.log(`   POST   /api/auth/verify-otp - Verify OTP (admin provides to user)`);
        console.log(`   POST   /api/auth/signup - Complete signup (requires admin verification)`);
        console.log(`   POST   /api/auth/login - Login`);
        console.log(`   GET    /api/auth/me - Get current user`);
        console.log(`\n   📄 INVOICES:`);
        console.log(`   GET    /api/invoices (Role-based: User sees own, Admin sees all, Super Admin sees requested)`);
        console.log(`   GET    /api/invoices/:id - Get single invoice`);
        console.log(`   GET    /api/invoices/next-number - Generate next invoice number`);
        console.log(`   POST   /api/invoices (Create/edit invoices)`);
        console.log(`   DELETE /api/invoices/:id (ADMIN only)`);
        console.log(`\n   ✍️ eSign WORKFLOW:`);
        console.log(`   POST   /api/invoices/:id/request-esign (ADMIN only) - Request eSign approval`);
        console.log(`   POST   /api/invoices/:id/final-esign (SUPER ADMIN only) - Manual eSign approval`);
        console.log(`   POST   /api/invoices/:id/esign (SUPER ADMIN only) - CloudSigner digital approval`);
        console.log(`\n   📑 PDF:`);
        console.log(`   POST   /api/invoice/generate-pdf - Generate PDF from rendered invoice HTML`);
        console.log(`   POST   /api/invoices/:id/download-pdf (ADMIN/SUPER ADMIN only) - Download PDF`);
        console.log(`\n   👥 CLIENTS:`);
        console.log(`   GET    /api/clients (All users can view)`);
        console.log(`   POST   /api/clients (ADMIN only)`);
        console.log(`   PUT    /api/clients/:id (ADMIN only)`);
        console.log(`   DELETE /api/clients/:id (ADMIN only)`);
        console.log(`\n   🏦 BANKS:`);
        console.log(`   GET    /api/banks (All users can view)`);
        console.log(`   POST   /api/banks (ADMIN only)`);
        console.log(`   PUT    /api/banks/:id (ADMIN only)`);
        console.log(`   DELETE /api/banks/:id (ADMIN only)`);
        console.log(`   PATCH  /api/banks/:id/set-default (ADMIN only)`);
        console.log(`\n   📊 REPORTS:`);
        console.log(`   GET    /api/reports/invoice-summary (with filters)`);
        console.log(`   GET    /api/reports/monthly-summary`);
        console.log(`\n   ⚙️ SETTINGS:`);
        console.log(`   GET    /api/tax-settings`);
        console.log(`   GET    /api/tax-settings/default`);
        console.log(`   GET    /api/state-mapping`);
        console.log(`\n🔐 REGISTRATION FLOW:`);
        console.log(`   1️⃣ User fills signup form`);
        console.log(`   2️⃣ OTP sent to ADMIN email with user details`);
        console.log(`   3️⃣ Admin provides OTP to user`);
        console.log(`   4️⃣ User enters OTP to complete registration`);
        console.log(`   5️⃣ Account created only after admin approval`);
        console.log(`   💡 First user automatically becomes SUPER_ADMIN`);
        console.log(`\n💰 PAYMENT STATUS OPTIONS:`);
        console.log(`   ✅ paid - Full payment received`);
        console.log(`   ❌ unpaid - No payment received`);
        console.log(`   🚫 cancelled - Invoice cancelled`);
        console.log(`\n✅ eSign APPROVAL WORKFLOW:`);
        console.log(`   📝 created - Invoice created by User`);
        console.log(`   📨 requested - Admin requested eSign approval`);
        console.log(`   🔏 final_approved - Super Admin approved with eSign`);
        console.log(`\n=====================================\n`);
    });
}).catch(err => {
    console.error('❌ Failed to initialize database:', err);
    process.exit(1);
});


